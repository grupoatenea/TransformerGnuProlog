package co.edu.eafit.tvl.expression;

public interface GNUPrologExpression {
	public String toArithmeticForm();
}
