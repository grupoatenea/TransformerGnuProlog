package co.edu.eafit.tvl.expression;

public class GNUPrologTrueExpression implements GNUPrologExpression {

	@Override
	public String toArithmeticForm() {
		return "1";
	}

}
