package co.edu.eafit.tvl.expression;


public class GNUPrologZeroExpression implements GNUPrologExpression {

	@Override
	public String toArithmeticForm() {
		return "0";
	}
	
	

}
