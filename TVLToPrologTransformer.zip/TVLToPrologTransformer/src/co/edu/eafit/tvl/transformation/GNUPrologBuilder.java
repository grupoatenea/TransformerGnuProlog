package co.edu.eafit.tvl.transformation;

public interface GNUPrologBuilder {
	String build();
}
