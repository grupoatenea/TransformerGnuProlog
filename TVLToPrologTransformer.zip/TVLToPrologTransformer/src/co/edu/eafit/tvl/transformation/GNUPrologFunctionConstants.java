package co.edu.eafit.tvl.transformation;

public class GNUPrologFunctionConstants {
	
	public static final String FD_DOMAIN_FUNCTION = "fd_domain";
	public static final String APPEND_FUNCTION = "append";
	public static final String FD_LABELING_FUNCTION = "fd_labeling";
	
}
