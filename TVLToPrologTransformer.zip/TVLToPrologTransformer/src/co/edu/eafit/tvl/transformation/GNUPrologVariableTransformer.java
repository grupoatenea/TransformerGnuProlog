package co.edu.eafit.tvl.transformation;

public abstract class GNUPrologVariableTransformer {
	public abstract String getGNUPrologName();
}
